package com.example.avilesmartinez.practicas

class MarioBrosProvider {
    companion object{
        val MarioBrosLists = listOf<MarioBros>(
            MarioBros(
                "Mario",
                "https://mario.nintendo.com/static/86bd56fed456e9b642100519880b6a86/b3853/mario.png",
                "Heroe del Reino Champiñon",
                "Lanza bolas de hielo o fuego"
            ),
            MarioBros(
                "Luigi",
                "https://static.wikia.nocookie.net/shipping/images/c/c6/Luigi_Mario_Party_Switch.png/revision/latest?cb=20211012192207&path-prefix=es",
                "Hermano de Mario",
                "Mano de rayos"
            ),
            MarioBros(
                "Peach",
                "https://m.media-amazon.com/images/I/61G8X1UtXtL.jpg",
                "Princesa del reino Champiñon",
                "Puede flotar en el aire durante unos segundos"
            ),
            MarioBros(
                "Toad",
                "https://play.nintendo.com/images/Masthead_Toad.17345b1513ac044897cfc243542899dce541e8dc.9afde10b.png",
                "Hongo del Reino Champiñon",
                "Salta alto"
            )
        )
    }

}//Clase que alberga la lista de personajes juntos a sus datos.