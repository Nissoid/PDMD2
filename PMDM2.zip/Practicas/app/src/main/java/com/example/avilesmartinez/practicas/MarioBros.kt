package com.example.avilesmartinez.practicas

data class MarioBros(
    val nombre:String,
    val photo:String,
    val descripcion:String,
    val habilidades:String

)//Esta es la clase que alberga las variables que se muestran en la lista.