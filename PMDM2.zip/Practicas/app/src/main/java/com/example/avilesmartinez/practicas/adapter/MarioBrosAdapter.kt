package com.example.avilesmartinez.practicas.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.avilesmartinez.practicas.MarioBros
import com.example.avilesmartinez.practicas.R


class MarioBrosAdapter(private val MarioBrosList: List<MarioBros>, function: () -> Unit) :RecyclerView.Adapter<MarioBrosViewHolder>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MarioBrosViewHolder {
        val layoutInflater = LayoutInflater.from(parent.context)
        return MarioBrosViewHolder(layoutInflater.inflate(R.layout.item_mariobros, parent, false))
    }

    override fun getItemCount(): Int = MarioBrosList.size


    override fun onBindViewHolder(holder: MarioBrosViewHolder, position: Int) {
        val item = MarioBrosList[position]
        holder.render(item)
    }
}