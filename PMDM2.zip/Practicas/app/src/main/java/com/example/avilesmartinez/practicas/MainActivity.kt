package com.example.avilesmartinez.practicas


import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.avilesmartinez.practicas.adapter.MarioBrosAdapter
import com.example.avilesmartinez.practicas.databinding.ActivityMainBinding



class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding//Muestra la vista principal

    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        enableEdgeToEdge()

        initRecyclerView()
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.mcontextualetiqueta, menu)
        return super.onCreateOptionsMenu(menu)
    }//Muestra el menú de acerca de

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        Toast.makeText(this, "Aplicación desarrollada por Daniel Avilés Martínez. Versión 1.0", Toast.LENGTH_LONG).show()
        return super.onOptionsItemSelected(item)
    }//Muestra el texto al clickar en acerca de



    private fun initRecyclerView() {
        Toast.makeText(this, "Bienvenidos al mundo de Mario", Toast.LENGTH_LONG).show()//Muestra el texto de bienvenida
        binding.rcPrincipal.layoutManager = LinearLayoutManager(this)
        binding.rcPrincipal.adapter = MarioBrosAdapter(MarioBrosProvider.MarioBrosLists) {

        }//Muestra la lista de personajes

    }

}





