package com.example.avilesmartinez.practicas

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.bumptech.glide.Glide
import com.example.avilesmartinez.practicas.databinding.ActivityDetailBinding

class DetailActivity : AppCompatActivity() {
    companion object{
        const val EXTRA_MarioBrosPhoto = "DetailActivity:photo"
        const val EXTRA_MarioBrosNombre = "DetailActivity:nombre"
        const val EXTRA_MarioBrosDescripcion = "DetailActivity:descripcion"
        const val EXTRA_MarioBrosHabilidades = "DetailActivity:habilidades"
    }//Contiene los valores que muestra al clickar en un personaje.
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val binding = ActivityDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)
        enableEdgeToEdge()

        val nombre = intent.getStringExtra(EXTRA_MarioBrosNombre)//muestra el nombre del personaje
        val descripcion = intent.getStringExtra(EXTRA_MarioBrosDescripcion)//muestra la descripcion del personaje
        val habilidades = intent.getStringExtra(EXTRA_MarioBrosHabilidades)//muestra las habilidades del personaje
        val photo = intent.getStringExtra(EXTRA_MarioBrosPhoto)//muestra la foto del personaje

        binding.tvNombre.text = nombre
        binding.tvDescripcion.text = descripcion
        binding.tvHabilidad.text = habilidades
        Glide.with(binding.ivdetail.context).load(photo).into(binding.ivdetail)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }

}