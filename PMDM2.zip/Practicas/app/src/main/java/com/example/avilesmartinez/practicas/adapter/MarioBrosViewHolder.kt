package com.example.avilesmartinez.practicas.adapter


import android.content.Intent
import android.view.View
import android.widget.Toast
import androidx.core.content.ContextCompat.startActivity
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.avilesmartinez.practicas.DetailActivity
import com.example.avilesmartinez.practicas.MarioBros
import com.example.avilesmartinez.practicas.databinding.ItemMariobrosBinding



class MarioBrosViewHolder(view: View) : RecyclerView.ViewHolder(view) {

    val binding = ItemMariobrosBinding.bind(view)

    fun render(marioBrosModel: MarioBros) {
        binding.tvMarioBros.text = marioBrosModel.nombre
        Glide.with(binding.ivMarioBros.context).load(marioBrosModel.photo).into(binding.ivMarioBros)

        binding.ivMarioBros.setOnClickListener {
            val intent = Intent(binding.ivMarioBros.context, DetailActivity::class.java)

            Toast.makeText(
                binding.ivMarioBros.context,
                "Se ha seleccionado el personaje ${marioBrosModel.nombre}",
                Toast.LENGTH_SHORT
            ).show()

            intent.putExtra(DetailActivity.EXTRA_MarioBrosNombre, marioBrosModel.nombre)
            intent.putExtra(DetailActivity.EXTRA_MarioBrosDescripcion, marioBrosModel.descripcion)
            intent.putExtra(DetailActivity.EXTRA_MarioBrosHabilidades, marioBrosModel.habilidades)
            intent.putExtra(DetailActivity.EXTRA_MarioBrosPhoto, marioBrosModel.photo)

            startActivity(binding.ivMarioBros.context, intent, null)

        }
    }

}